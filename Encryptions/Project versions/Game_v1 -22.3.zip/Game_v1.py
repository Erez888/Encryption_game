import tkinter as tk
from pickle import GLOBAL
from tkinter import ttk
from tkinter import messagebox
from Encryptions import Game_instructions as instructions
from Encryptions import Ceaser_Cypher as Ceaser
from Encryptions import Zigzag as Zigzag
from Encryptions import Vigenere_cipher as Vigenere
from Encryptions import AZBY
import nltk # needs pip install


nltk.download('words')
from nltk.corpus import words
import random
import string

def choose_cypher():
    cyphers = ["Ceaser", "Zigzag", "Vigenere", "AZBY"]
    cypher = random.choice(cyphers)
    return cypher
#the length is needed for the rail fence cypher


def choose_key(cypher, length):
    if cypher == "Ceaser":
        key = random.randint(0, 26)
        return key
    elif cypher == "Zigzag":
        key = random.randint(2, length - 1)
        return key
    elif cypher == "Vigenere":
        characters = string.ascii_lowercase
        key = ''.join(random.choices(characters, k=random.randint(2, 5)))
        return key
    elif cypher == "AZBY":
        return  None
    else:
        print("Error generating key")
        return
def generate_question():
    word_list = words.words()

    options = ["Encrypt", "Decrypt"]
    option = random.choice(options)
    if option == "Encrypt":
        question_cypher = choose_cypher()
        question_word = random.choice(word_list).lower()
        question_key = choose_key(cypher=question_cypher, length = len(question_word))
        if question_key is None:
            question_text = f'Encrypt "{question_word}" with {question_cypher}'
        else:
            question_text = f'Encrypt "{question_word}" with {question_cypher} with a key of {question_key}'
        return question_text, question_word, question_cypher, question_key, option
    elif option == "Decrypt":
        question_cypher = choose_cypher()
        question_word = random.choice(word_list).lower()
        question_key = choose_key(cypher=question_cypher, length = len(question_word))
        if question_cypher == "Ceaser":
            encrypted_word = Ceaser.CeaserCyhper(p_text=question_word, key = question_key)
        elif question_cypher == "Zigzag":
            encrypted_word = Zigzag.encrypt(text = question_word, depth = question_key)
        elif question_cypher == "Vigenere":
            encrypted_word = Vigenere.encrypt(message=question_word, key = question_key)
        elif question_cypher == "AZBY":
            encrypted_word = AZBY.AZBY(p_text=question_word)
        if question_key == None:
            question_text = (f"{encrypted_word} was encrypted with {question_cypher}.\n Decrypt it:")
        else:
            question_text = (f"{encrypted_word} was encrypted with {question_cypher}, \n with a key of {question_key}.\n Decrypt it:")
        return question_text, question_word, question_cypher, question_key, option


def Generate_right_option(question_word, question_cypher, question_key, method):
    if method == "Encrypt":
        if question_cypher == "Ceaser":
            correct_option = Ceaser.CeaserCyhper(p_text=question_word, key=question_key)
            return correct_option, question_word,question_cypher, question_key, method
        elif question_cypher == "Zigzag":
            correct_option = Zigzag.encrypt(text = question_word, depth= question_key)
            return correct_option, question_word,question_cypher, question_key, method
        elif question_cypher == "Vigenere":
            correct_option = Vigenere.encrypt(message=question_word, key = question_key)
            return  correct_option, question_word,question_cypher, question_key, method
        elif question_cypher == "AZBY":
            correct_option = AZBY.AZBY(p_text=question_word)
            return correct_option, question_word,question_cypher, question_key, method
    elif method == "Decrypt":
        return question_word, question_word, question_cypher, question_key, method


def Generate_wrong_options(right_option, question_word, question_cypher, question_key, method):
    if method == "Decrypt":
        word_list = words.words()
        wrong_options = []
        while len(wrong_options) < 3:
            option = random.choice(word_list).lower()
            if option != right_option and option not in wrong_options:
                wrong_options.append(option)
        return wrong_options[0], wrong_options[1], wrong_options[2]

    elif method == "Encrypt":
        def generate_one_wrong():
            option_cypher = choose_cypher()
            option_key = choose_key(cypher=option_cypher, length=len(question_word))
            if option_cypher == "Ceaser":
                return Ceaser.CeaserCyhper(p_text=question_word, key=option_key)
            elif option_cypher == "Zigzag":
                return Zigzag.encrypt(text=question_word, depth=option_key)
            elif option_cypher == "Vigenere":
                return Vigenere.encrypt(message=question_word, key=option_key)
            elif option_cypher == "AZBY":
                return AZBY.AZBY(p_text=question_word)

        wrong_options = []
        while len(wrong_options) < 3:
            option = generate_one_wrong()
            if option != right_option and option not in wrong_options:
                wrong_options.append(option)
        return wrong_options[0], wrong_options[1], wrong_options[2]





def launch_game():
    game_window = tk.Toplevel()
    game_window.geometry("800x700")
    game_window.title("Game")



    question_text, question_word, question_cypher, question_key, question_method = generate_question()
    correct_option = Generate_right_option(question_word = question_word, question_cypher = question_cypher, question_key = question_key, method= question_method)[0]
    wrong_option1, wrong_option2, wrong_option3 = Generate_wrong_options(right_option= correct_option, question_word=question_word, question_cypher=question_cypher, question_key=question_key, method=question_method)
    print(f"correct option: {correct_option}")
    question_label = tk.Label(game_window, text= question_text, font=("Courier", 20, "bold"), wraplength=600)
    question_label.place(x = 100, y = 100)

    # Placeholder — main game UI will go here

    selected = tk.StringVar()
    options = [correct_option, wrong_option1, wrong_option2, wrong_option3]
    random.shuffle(options)

    answer1 = options[0]
    answer2 = options[1]
    answer3 = options[2]
    answer4 = options[3]
    radio_font = ("Courier", 18, "bold")
    option1 = tk.Radiobutton(game_window, text=answer1, variable=selected, value=answer1, font = radio_font)
    option2 = tk.Radiobutton(game_window, text=answer2, variable=selected, value=answer2, font = radio_font)
    option3 = tk.Radiobutton(game_window, text=answer3, variable=selected, value=answer3, font = radio_font)
    option4 = tk.Radiobutton(game_window, text=answer4, variable=selected, value=answer4, font = radio_font)
    option1.place(x=350, y=250)
    option2.place(x=350, y=280)
    option3.place(x=350, y=310)
    option4.place(x=350, y=340)









instructions.menu(on_begin=launch_game)

